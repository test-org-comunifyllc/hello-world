module=$1

if [ -z "$module" ]
then
      echo "Please enter a valid module name as first parameter"
else
    #create a controller file
    mkdir -p src/modules/$module/controller
    touch src/modules/$module/controller/$module.controller.ts

    cat << EOF >> src/modules/$module/controller/$module.controller.ts
    import { Next, Context } from 'koa';

    import { ${module^}Dto } from '@modules/${module}/dto/${module}.dto';
    import { ${module^} } from '@modules/${module}/interface/${module}.interface';
    import ${module^}Service from '@modules/${module}/services/${module}.service';

    class ${module^}Controller {
        public ${module^}Service = new ${module^}Service();
        public get${module^} = async (ctx: Context) => {
        const findAll${module^}Data: ${module^}[] = await this.${module^}Service.findAll${module^}();
        ctx.response.body = { data: findAll${module^}Data, message: 'findAll' };
        ctx.response.status = 200;
        };

        public get${module^}ById = async (ctx: Context) => {
        const ${module}Id = ctx.params.id;
        const findOne${module^}Data: ${module^} = await this.${module^}Service.find${module^}ById(${module}Id);
        ctx.response.body = { data: findOne${module^}Data, message: 'findOne' };
        ctx.response.status = 200;
        };

        public create${module^} = async (ctx: Context) => {
        const ${module}Data: ${module^}Dto = ctx.request.body;
        const create${module^}Data: ${module^} = await this.${module^}Service.create${module^}(${module}Data);
        ctx.response.body = { data: create${module^}Data, message: 'created' };
        ctx.response.status = 201;
        };

        public update${module^} = async (ctx: Context) => {
        const ${module}Id = ctx.params.id;
        const ${module}Data: ${module^}Dto = ctx.request.body;
        const update${module^}Data: ${module^} = await this.${module^}Service.update${module^}(${module}Id, ${module}Data);
        ctx.response.body = { data: update${module^}Data, message: 'updated' };
        ctx.response.status = 201;
        };

        public delete${module^} = async (ctx: Context) => {
        const ${module}Id = ctx.params.id;
        const delete${module^}Data: {} = await this.${module^}Service.delete${module^}(${module}Id);
        ctx.response.body = { data: delete${module^}Data, message: 'deleted' };
        ctx.response.status = 201;
        };

    }

    export default ${module^}Controller;
EOF
    #create a dto file
    mkdir -p src/modules/$module/dto
    touch src/modules/$module/dto/$module.dto.ts

    cat << EOF >> src/modules/$module/dto/$module.dto.ts
    import { IsString } from 'class-validator';

    export class ${module^}Dto {
        @IsString()
        public email: string;

        @IsString()
        public userName: string;

        @IsString()
        public password: string;
    }
EOF

    #create an interface file
    mkdir -p src/modules/$module/interface
    touch src/modules/$module/interface/$module.interface.ts

    cat << EOF >> src/modules/$module/interface/$module.interface.ts
    export interface ${module^} {
          email: string;
          userName: string;
          password: string;
    }
EOF

    #create a routes file
    mkdir -p src/modules/$module/routes
    touch src/modules/$module/routes/$module.route.ts

    cat << EOF >> src/modules/$module/routes/$module.route.ts
    import { Context, DefaultState } from 'koa';
    import Router from 'koa-router';

    import { Routes } from '@interfaces/interface';
    import { ${module^}Dto } from '@modules/${module}/dto/${module}.dto';
    import ${module^}Controller from '@modules/${module}/controller/${module}.controller';
    import validationMiddleware from '@middlewares/validation.middleware';

    class ${module^}Route implements Routes {
        public router = new Router<DefaultState, Context>();
        public ${module^}Controller = new ${module^}Controller();

        constructor() {
            this.initializeRoutes();
        }

        private initializeRoutes() {
            this.router.get("/${module}", this.${module^}Controller.get${module^});
            this.router.get("/${module}/:id", this.${module^}Controller.get${module^}ById);
            this.router.post("/${module}", validationMiddleware(${module^}Dto, 'body'), this.${module^}Controller.create${module^});
            this.router.put("/${module}/:id", validationMiddleware(${module^}Dto, 'body', true), this.${module^}Controller.update${module^});
            this.router.delete("/${module}/:id", this.${module^}Controller.delete${module^});
        }

    }
    
    export default ${module^}Route 
EOF

    #create a service file
    mkdir -p src/modules/$module/services
    touch src/modules/$module/services/$module.service.ts

    cat << EOF >> src/modules/$module/services/$module.service.ts
    import { hash } from 'bcrypt';

    import { ${module^}Dto } from '@modules/${module}/dto/${module}.dto';
    import { HttpException } from '@exceptions/HttpException';
    import { isEmpty } from '@utils/util';
    import prisma from '@utils/prisma';
    import { ${module^} } from '@modules/${module}/interface/${module}.interface';
    
    class ${module^}Service {
        public async findAll${module^}(): Promise<${module^}[]> {
        const all${module^}: ${module^}[] = await prisma.${module}.findMany();
        return all${module^};
        }

        public async find${module^}ById(${module}Id: string): Promise<${module^}> {
        if (isEmpty(${module}Id)) throw new HttpException(400, "The user is unavailable");
        const find${module^}: ${module^} = await prisma.${module}.findUnique({
            where: {
             id: ${module}Id,
            },
        });
         if (!find${module^}) throw new HttpException(409, "You're not the user");
            return find${module^};
        }

        public async create${module^}(${module}Data: ${module^}Dto): Promise<${module^}> {
        if (isEmpty(${module}Data)) throw new HttpException(400, "You're not a user");

        const find${module^}: ${module^} = await prisma.${module}.findUnique({ where: { userName: ${module}Data.userName } });
        if (find${module^}) throw new HttpException(409, 'Your account already exists');

        const hashedPassword = await hash(${module}Data.password, 10);
        const create${module^}Data: ${module^} = await prisma.${module}.create({ data: { ...${module}Data, password: hashedPassword } });

        return create${module^}Data;
        }

        public async update${module^}(${module}Id: string, ${module}Data: ${module^}Dto): Promise<${module^}> {
        if (isEmpty(${module}Data)) throw new HttpException(400, "You're not a user");

        const find${module^}: ${module^} = await prisma.${module}.findUnique({ where: { id: ${module}Id } });
        if (!find${module^}) throw new HttpException(409, "You're not user");

        const hashedPassword = await hash(${module}Data.password, 10);
        await prisma.${module}.update({ data: { ...${module}Data, password: hashedPassword }, where: { id: ${module}Id } });

        const update${module^}: ${module^} = await prisma.${module}.findUnique({ where: { id: ${module}Id } });
        return update${module^};
        }

        public async delete${module^}(${module}Id: string): Promise<${module^}> {
        if (isEmpty(${module}Id)) throw new HttpException(400, "You're not a user");

        const find${module^}: ${module^} = await prisma.${module}.findUnique({ where: { id: ${module}Id } });
        if (!find${module^}) throw new HttpException(409, "You're not a user");

        await prisma.${module}.delete({ where: { id: ${module}Id } });

        return find${module^};
        }
    }

    export default ${module^}Service
EOF

    #write to schema.prisma file
    cat << EOF >> prisma/schema.prisma

model ${module^} {
  id             String       @id @default(uuid())
  email          String       @unique @db.VarChar(45)
  userName       String       @unique @db.VarChar(45)
  password       String       @db.VarChar(255) 
  createdAt      DateTime     @default(now())
  updatedAt      DateTime     @updatedAt
}
EOF

#write to schema.prisma file
sed -i "1i import ${module^}Route from '@modules/${module}/routes/${module}.route' " src/server.ts
sed -i "s/])/, new ${module^}Route()])/" src/server.ts

fi



