import passport from 'passport';
import { Strategy as GoogleStrategy, StrategyOptions } from 'passport-google-oauth20';
import { GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, PORT } from '@config';
import prisma from '@utils/prisma';

//in progress
const passportConfig: StrategyOptions = {
  clientID: GOOGLE_CLIENT_ID,
  clientSecret: GOOGLE_CLIENT_SECRET,
  callbackURL: `http://localhost:${PORT}/auth/google/callback`,
  proxy: true,
};

const googleLogin = new GoogleStrategy(passportConfig, async (accessToken, refreshToken, profile, done) => {
  try {
    const findUser = await prisma.user.findUnique({
      where: {
        email: profile._json.email,
      },
    });
    if (findUser) {
      if (findUser.googleId === null) {
        //update the user with googleID
      }
      done(null, findUser);
    }
    done(null, 'new User');
    //else {
    //  create a new user and return
    // }
  } catch (error) {
    console.log(error);
  }
});

passport.use(googleLogin);
