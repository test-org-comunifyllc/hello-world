import { Strategy, ExtractJwt, StrategyOptions } from 'passport-jwt';
import passport from 'koa-passport';
import { SECRET_KEY } from '@config';
import { DataStoredInToken } from '@/modules/auth/interface/auth.interface';
import prisma from '@utils/prisma';

const jwtOptions: StrategyOptions = {
  jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
  secretOrKey: SECRET_KEY,
};

passport.use(
  new Strategy(jwtOptions, async function (jwt_payload: DataStoredInToken, done) {
    const findUser = await prisma.user.findUnique({
      where: {
        id: jwt_payload.id,
      },
    });
    if (findUser) {
      return done(null, findUser);
    }
    return done(null, false, null);
  }),
);
