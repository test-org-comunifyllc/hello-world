import { config } from 'dotenv';
config({ path: `.env.${process.env.NODE_ENV || 'development'}.local` });

export const CREDENTIALS = process.env.CREDENTIALS === 'true';
export const {
  NODE_ENV,
  PORT,
  DATABASE_URL,
  SECRET_KEY,
  REFRESH_KEY,
  EMAIL_KEY,
  LOG_FORMAT,
  LOG_DIR,
  ORIGIN,
  SEND_GRID,
  GOOGLE_CLIENT_ID,
  GOOGLE_CLIENT_SECRET,
} = process.env;
