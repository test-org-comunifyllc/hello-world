import { Next, Context } from 'koa';
import { plainToInstance } from 'class-transformer';
import { validate, ValidationError } from 'class-validator';

import { HttpException } from '@exceptions/HttpException';

const validationMiddleware = (
  type: any,
  value: string | 'body' | 'query' | 'params' = 'body',
  skipMissingProperties = false,
  whitelist = true,
  forbidNonWhitelisted = true,
) => {
  return async (ctx: Context, next: Next) => {
    const errors = await validate(plainToInstance(type, ctx.request[value]), { skipMissingProperties, whitelist, forbidNonWhitelisted });
    if (errors.length > 0) {
      const message = errors.map((error: ValidationError) => Object.values(error.constraints)).join(', ');
      throw new HttpException(400, message);
    } else {
      await next();
    }
  };
};

export default validationMiddleware;
