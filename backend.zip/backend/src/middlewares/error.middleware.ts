import { Context, Next } from 'koa';

import { logger } from '@utils/logger';
import { ValidationError } from '@utils/validation';
import { isObject } from '@utils/util';

const errorMiddleware = async (ctx: Context, next: Next) => {
  return next().catch(err => {
    let status: number = err.status || 500;
    let message: any = err.message || 'Something went wrong';

    if (err instanceof ValidationError) {
      status = 400;
      message = err.errors.map(e => ({
        path: e.path.join('.'),
        message: e.message,
      }));
    }
    ctx.status = status;
    ctx.body = message;
    logger.error(`[${ctx.method}] ${ctx.path} >> StatusCode:: ${status}, Message:: ${isObject(message) ? JSON.stringify(message) : message}`);
  });
};

export default errorMiddleware;
