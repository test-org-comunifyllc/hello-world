import { Next } from 'koa';
import { verify } from 'jsonwebtoken';

import { EMAIL_KEY } from '@config';
import { HttpException } from '@exceptions/HttpException';
import prisma from '@utils/prisma';
import { DataStoredInEmailToken, RequestWithEmailToken } from '@modules/auth/interface/email.interface';

const emailVerification = async (ctx: RequestWithEmailToken, next: Next) => {
  try {
    const token = ctx.params.id;
    if (token) {
      const emailKey: string = EMAIL_KEY;

      const verificationResponse = verify(token, emailKey) as DataStoredInEmailToken;
      const findUser = await prisma.user.findUnique({
        where: { id: verificationResponse.id },
      });
      if (findUser.isVerified) throw new HttpException(401, 'Email already Verified');
      const findToken = await prisma.emailToken.findUnique({
        where: {
          token: token,
        },
      });

      if (findToken) {
        const currentDate = new Date();
        const expiryDate = new Date(findToken.expiry);
        if (currentDate > expiryDate) throw new HttpException(401, 'Link expired');
        ctx.tokenData = findToken;
        return await next();
      } else {
        throw new HttpException(401, 'Invalid Verification Link.');
      }
    } else {
      throw new HttpException(401, 'Invalid Verification Link');
    }
  } catch (err) {
    if (err.message === 'jwt expired') {
      throw new HttpException(401, 'Link expired, click on resend link for verification.');
    }
    throw new HttpException(401, err?.message);
  }
};

export default emailVerification;
