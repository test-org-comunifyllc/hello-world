import { Next } from 'koa';
import { verify } from 'jsonwebtoken';
import passport from 'koa-passport';

import { SECRET_KEY } from '@config';
import { HttpException } from '@exceptions/HttpException';
import { DataStoredInToken, RequestWithUser } from '@modules/auth/interface/auth.interface';
import prisma from '@utils/prisma';
import { User } from '@modules/users/interface/users.interface';

//middleware using jwt
// const authMiddleware = async (ctx: RequestWithUser, next: Next) => {
//   try {
//     const Authorization = ctx.header.authorization ? ctx.header.authorization.split('Bearer ')[1] : null;
//     if (Authorization) {
//       const secretKey: string = SECRET_KEY;
//       const verificationResponse = verify(Authorization, secretKey) as DataStoredInToken;
//       const userId = verificationResponse.id;
//       const findUser = await prisma.user.findUnique({
//         where: {
//           id: userId,
//         },
//       });
//       if (findUser) {
//         ctx.user = findUser;
//         return await next();
//       } else {
//         throw new HttpException(401, 'Wrong authentication token');
//       }
//     } else {
//       throw new HttpException(404, 'Authentication token missing');
//     }
//   } catch (err) {
//     if (err.message === 'jwt expired') {
//       throw new HttpException(401, 'Token expired');
//     }
//     throw new HttpException(401, 'Wrong authentication token');
//   }
// };

//middleware using passport-jwt
const pass_middleware = async (ctx: RequestWithUser, next: Next) => {
  await passport.authenticate('jwt', { session: false }, async function (_err, user: User, info) {
    if (info?.message) {
      throw new HttpException(401, info.message);
    }
    if (user) {
      if (!user.isVerified) throw new HttpException(401, 'Email not verfied');
      ctx.user = user;
      return await next();
    } else {
      throw new HttpException(401, 'Invalid authentication token');
    }
  })(ctx, next);
};

export default pass_middleware;
