import App from '@/app';
import AuthRoute from '@modules/auth/routes/auth.route';
import EmailRoute from '@modules/auth/routes/email.routes';
import GoogleRoute from '@modules/auth/routes/google.route';
import IndexRoute from './router/index.router';
import UsersRoute from '@modules/users/routes/users.route';
import { validateEnv } from '@utils/validation';

validateEnv();

const app = new App([new IndexRoute(), new AuthRoute(), new EmailRoute(), new GoogleRoute(), new UsersRoute()]);

app.listen();
