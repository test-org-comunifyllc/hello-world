import Router from 'koa-router';
import { Context, DefaultState } from 'koa';
import { koaSwagger } from 'koa2-swagger-ui';
import yamljs from 'yamljs';

import { Routes } from '@interfaces/interface';
class IndexRoute implements Routes {
  public path = '/';
  public router = new Router<DefaultState, Context>();

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    this.router.get(`${this.path}`, (ctx: Context) => {
      ctx.response.status = 200;
    });
    const spec = yamljs.load('./swagger.yaml');
    this.router.get('/docs', koaSwagger({ routePrefix: false, swaggerOptions: { spec: spec } }));
  }
}

export default IndexRoute;
