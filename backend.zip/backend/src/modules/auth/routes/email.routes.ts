import { DefaultState } from 'koa';
import Router from 'koa-router';

import EmailController from '@modules/auth/controller/email.controller';
import emailVerification from '@middlewares/emailVerify.middleware';
import { RequestWithEmailToken } from '@modules/auth/interface/email.interface';
import { Routes } from '@interfaces/interface';

class EmailRoute implements Routes {
  public path = '/auth';
  public router = new Router<DefaultState, RequestWithEmailToken>();
  public emailController = new EmailController();

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    //need to change to post
    this.router.get(`${this.path}/verifyEmail/:id`, emailVerification, this.emailController.verifyEmail);
    this.router.get(`${this.path}/resendEmail/:id`, this.emailController.resendVerifyEmail);
  }
}

export default EmailRoute;
