import { DefaultState } from 'koa';
import Router from 'koa-router';

import AuthController from '@modules/auth/controller/auth.controller';
import authMiddleware from '@middlewares/auth.middleware';
import { CreateUserDto } from '@modules/users/dto/users.dto';
import { LoginUserDto } from '@modules/auth/dto/auth.dto';
import { RequestWithUser } from '@modules/auth/interface/auth.interface';
import { Routes } from '@interfaces/interface';
import validationMiddleware from '@middlewares/validation.middleware';

class AuthRoute implements Routes {
  public path = '/auth';
  public router = new Router<DefaultState, RequestWithUser>();
  public authController = new AuthController();

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    this.router.post(`${this.path}/signup`, validationMiddleware(CreateUserDto, 'body'), this.authController.signUp);
    this.router.post(`${this.path}/login`, validationMiddleware(LoginUserDto, 'body'), this.authController.logIn);
    this.router.post(`${this.path}/logout`, authMiddleware, this.authController.logOut);
    this.router.post(`${this.path}/refreshToken`, this.authController.refreshToken);
  }
}

export default AuthRoute;
