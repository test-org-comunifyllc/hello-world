import { Context, DefaultContext, DefaultState } from 'koa';
import Router from 'koa-router';
import passport from 'koa-passport';

import { Routes } from '@interfaces/interface';

class GoogleRoute implements Routes {
  public path = '/auth';
  public router = new Router();

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    this.router.get(
      `${this.path}/google`,
      passport.authenticate('google', {
        scope: ['profile', 'email'],
      }),
    );
    this.router.get(
      `${this.path}/google/callback`,
      passport.authenticate('google', {
        failureRedirect: '/',
        session: false,
      }),
      (ctx: Context) => {
        ctx.redirect('/');
      },
    );
  }
}

export default GoogleRoute;
