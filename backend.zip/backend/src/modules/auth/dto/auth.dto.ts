import { IsString, IsEmail, IsOptional } from 'class-validator';
export class LoginUserDto {
  @IsEmail()
  @IsOptional()
  public email: string;

  @IsString()
  @IsOptional()
  public userName: string;

  @IsString()
  public password: string;
}
