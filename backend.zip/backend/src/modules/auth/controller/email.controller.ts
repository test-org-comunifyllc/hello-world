import { Context } from 'koa';

import EmailService from '@modules/auth/services/email.service';
import { HttpException } from '@exceptions/HttpException';
import { EmailToken, RequestWithEmailToken } from '../interface/email.interface';

class AuthController {
  public emailService = new EmailService();

  public verifyEmail = async (ctx: RequestWithEmailToken) => {
    const tokenData: EmailToken = ctx.tokenData;
    const { cookie, accessToken } = await this.emailService.verifyEmail(tokenData);
    ctx.response.set('Set-Cookie', [cookie]);
    ctx.response.body = { token: accessToken, message: 'Email  verification successful.' };
    ctx.response.redirect('/');
    ctx.response.status = 200;
  };

  public resendVerifyEmail = async (ctx: Context) => {
    const token = ctx.params.id;
    if (!token) throw new HttpException(404, 'Invalid missing');
    await this.emailService.resendVerifyEmail(token);
    ctx.response.body = { message: 'Email resend' };
    ctx.response.status = 200;
  };
}

export default AuthController;
