import { Context } from 'koa';

import AuthService from '@modules/auth/services/auth.service';
import { CreateUserDto } from '@modules/users/dto/users.dto';
import { HttpException } from '@exceptions/HttpException';
import { LoginUserDto } from '@modules/auth/dto/auth.dto';
import { User, UserAuth } from '@modules/users/interface/users.interface';
import { RequestWithUser } from '../interface/auth.interface';

class AuthController {
  public authService = new AuthService();

  public signUp = async (ctx: Context): Promise<void> => {
    const userData: CreateUserDto = ctx.request.body;
    const signUpUserData: User = await this.authService.signup(userData);
    ctx.response.body = { data: signUpUserData, message: 'signup' };
    ctx.response.status = 201;
  };

  public logIn = async (ctx: Context) => {
    const userData: LoginUserDto = ctx.request.body;
    const { cookie, accessToken } = await this.authService.login(userData);
    ctx.response.set('Set-Cookie', [cookie]);
    ctx.response.body = { token: accessToken, message: 'login' };
    ctx.response.status = 200;
  };

  public logOut = async (ctx: RequestWithUser) => {
    const token = ctx.header.cookie.split('=')[1];
    const userData: UserAuth = ctx.user;
    await this.authService.logout(userData, token);

    ctx.response.set('Set-Cookie', ['jwt=; Max-age=0']);
    ctx.response.body = { message: 'logout' };
    ctx.response.status = 200;
  };

  public refreshToken = async (ctx: Context) => {
    const token = ctx.header.cookie.split('=')[1];
    if (!token) {
      throw new HttpException(404, 'Token does not exist');
    }
    const { cookie, accessToken } = await this.authService.refreshToken(token);
    ctx.response.set('Set-Cookie', [cookie]);
    ctx.response.body = { token: accessToken, message: 'refresh' };
    ctx.response.status = 200;
  };
}

export default AuthController;
