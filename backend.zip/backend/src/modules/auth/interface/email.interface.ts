import { Context } from 'koa';

export interface EmailToken {
  id: string;
  token: string;
  userId: string;
  email: string;
  expiry: Date;
}

export interface RequestWithEmailToken extends Context {
  tokenData: EmailToken;
}
export interface DataStoredInEmailToken {
  id: string;
}
