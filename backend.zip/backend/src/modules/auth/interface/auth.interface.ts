import { Context } from 'koa';
import { UserAuth } from '@modules/users/interface/users.interface';

export interface DataStoredInToken {
  id: string;
  email: string;
  userName: string;
}

export interface TokenData {
  token: string;
  refreshToken: string;
}

export interface RequestWithUser extends Context {
  user: UserAuth;
}
