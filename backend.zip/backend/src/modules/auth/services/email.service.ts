import { HttpException } from '@exceptions/HttpException';
import prisma from '@utils/prisma';
import AuthService from './auth.service';
import { EmailToken } from '../interface/email.interface';

class EmailService {
  public authService = new AuthService();

  /**
   * @method verifyEmail
   * @param emailTokenData
   * @returns
   * @description  Verify email, updates user table, delete email token from db
   */
  public async verifyEmail(emailTokenData: EmailToken): Promise<{ cookie: string; accessToken: string }> {
    await prisma.user.update({
      data: {
        isVerified: true,
      },
      where: {
        id: emailTokenData.userId,
      },
    });

    const findUser = await prisma.user.findUnique({ where: { id: emailTokenData.userId } });
    await prisma.emailToken.delete({
      where: {
        token: emailTokenData.token,
      },
    });

    const { cookie, accessToken } = await this.authService.createLoginTokens(findUser);

    return { cookie, accessToken };
  }

  /**
   * @method resendVerifyEmail
   * @param token emailToken
   * @returns
   * @description  Resends email verification mail and delete previous token from db
   */
  public async resendVerifyEmail(token: string): Promise<void> {
    const tokenData = await prisma.emailToken.findUnique({
      where: {
        token: token,
      },
    });

    if (!tokenData) throw new HttpException(401, 'Invalid Verification Link');
    await this.authService.sendVerificationLink(tokenData.userId, tokenData.email);

    await prisma.emailToken.delete({
      where: {
        token: token,
      },
    });
  }
}

export default EmailService;
