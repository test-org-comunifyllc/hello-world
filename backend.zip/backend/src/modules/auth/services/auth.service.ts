import { compare, hash } from 'bcrypt';
import { sign, verify } from 'jsonwebtoken';

import { SECRET_KEY, REFRESH_KEY, EMAIL_KEY, PORT } from '@config';
import { CreateUserDto } from '@modules/users/dto/users.dto';
import { DataStoredInToken, TokenData } from '@modules/auth/interface/auth.interface';
import { DataStoredInEmailToken } from '@modules/auth/interface/email.interface';
import { HttpException } from '@exceptions/HttpException';
import { isEmpty } from '@utils/util';
import { LoginUserDto } from '@modules/auth/dto/auth.dto';
import prisma from '@utils/prisma';
import { User, UserAuth } from '@modules/users/interface/users.interface';
import sendgrid from '@utils/email';

class AuthService {
  public refreshExpiry = 5; //days
  public tokenExpiry = 15; //minutes
  public emailExpiry = 1; //hour

  /**
   * @method signup
   * @param userData
   * @returns createUserData
   * @description Create a new user in db.
   */
  public async signup(userData: CreateUserDto): Promise<User> {
    if (isEmpty(userData)) throw new HttpException(400, 'Empty Userdata');

    let findUser: User = await prisma.user.findUnique({ where: { email: userData.email } });
    if (findUser) throw new HttpException(409, `Your email ${userData.email} already exists`);
    findUser = await prisma.user.findUnique({ where: { userName: userData.userName } });
    if (findUser) throw new HttpException(409, `User Name ${userData.userName} already exists`);
    findUser = await prisma.user.findUnique({ where: { companyName: userData.companyName ?? '' } });
    if (findUser) throw new HttpException(409, `Company Name ${userData.companyName} already exists`);

    const hashedPassword = await hash(userData.password, 10);

    const userDBData = { ...userData, password: hashedPassword };
    const createUserData: User = await prisma.user.create({
      data: userDBData,
    });

    await this.sendVerificationLink(createUserData.id, createUserData.email);
    return createUserData;
  }

  /**
   * @method logIn
   * @param userData
   * @returns {cookie,accessToken}
   * @description logins in user, store refresh token to db and returns refresh token as cookie and access token in body.
   */
  public async login(userData: LoginUserDto): Promise<{ cookie: string; accessToken: string }> {
    let findUser: User;

    if (isEmpty(userData)) throw new HttpException(400, 'Empty Userdata');

    if (!userData.email && !userData.userName) throw new HttpException(404, `Please provide a username or email ID to login`);
    if (userData?.email) {
      findUser = await prisma.user.findUnique({ where: { email: userData.email } });
    }
    if (userData?.userName) {
      findUser = await prisma.user.findUnique({ where: { userName: userData.userName } });
    }
    if (!findUser) throw new HttpException(409, `The username or email ID entered is not Signed Up, please Sign up to login`);

    const isPasswordMatching: boolean = await compare(userData.password, findUser.password);
    if (!isPasswordMatching) throw new HttpException(409, 'Oops! The password entered is incorrect');

    const { cookie, accessToken } = await this.createLoginTokens(findUser);

    return { cookie, accessToken };
  }

  /**
   * @method logOut
   * @param userData
   * @description logout user and delete refresh token from db.
   */
  public async logout(userData: UserAuth, token: string): Promise<void> {
    if (isEmpty(userData)) throw new HttpException(400, 'Empty Userdata');

    const findUser: User = await prisma.user.findUnique({ where: { email: userData.email } });
    if (!findUser) throw new HttpException(401, 'User not found');
    await prisma.userToken.delete({ where: { token: token } });
  }

  /**
   * @method refreshToken
   * @param token:refresh token
   * @returns {cookie,accessToken}
   * @description takes in refesh token verify and returns new refresh token and auth token.
   */
  public async refreshToken(token: string): Promise<{ cookie: string; accessToken: string }> {
    const findUser: User = await this.verifyRefreshToken(token);
    const tokenData = this.createToken(findUser);
    const currentDate = new Date();
    currentDate.setDate(currentDate.getDate() + this.refreshExpiry);
    await prisma.userToken.update({
      data: {
        token: tokenData.refreshToken,
        expiry: currentDate,
      },
      where: {
        token: token,
      },
    });
    const cookie = this.createCookie(tokenData);
    const accessToken = tokenData.token;
    return { cookie, accessToken };
  }

  /**
   * @method verifyRefreshToken
   * @param token:refresh token
   * @returns findUser
   * @description  verify token(signature, exists in db, expiry and user) and returns user info.
   */
  private async verifyRefreshToken(token: string): Promise<User> {
    try {
      const refreshKey: string = REFRESH_KEY;
      const verificationResponse = verify(token, refreshKey) as DataStoredInToken;
      const tokenCheck = await prisma.userToken.findUnique({
        where: {
          token: token,
        },
      });
      if (!tokenCheck) throw new HttpException(404, 'Token does not exist');

      const expiryDate: Date = new Date(tokenCheck.expiry);
      const currentDate = new Date();
      if (currentDate > expiryDate) {
        throw new HttpException(401, 'Token expired');
      }

      const userId = verificationResponse.id;
      const findUser = await prisma.user.findUnique({
        where: {
          id: userId,
        },
      });
      if (!findUser) {
        throw new HttpException(401, 'Wrong authentication token');
      }
      return findUser;
    } catch (err) {
      if (err.message === 'jwt expired') {
        throw new HttpException(401, 'Token expired');
      }
      throw new HttpException(401, 'Wrong authentication token');
    }
  }

  /**
   * @method createToken
   * @param user
   * @returns {TokenData}
   * @description  Creates auth and refresh token
   */
  public createToken(user: User): TokenData {
    const dataStoredInToken: DataStoredInToken = { id: user.id, email: user.email, userName: user.userName };
    const secretKey: string = SECRET_KEY;
    const refreshKey: string = REFRESH_KEY;

    return {
      token: sign(dataStoredInToken, secretKey, { expiresIn: `${this.tokenExpiry}m` }),
      refreshToken: sign(dataStoredInToken, refreshKey, { expiresIn: `${this.refreshExpiry}d` }),
    };
  }

  /**
   * @method createCookie
   * @param tokenData
   * @returns cookie string
   * @description  Creates http only cookie with refresh token
   */
  public createCookie(tokenData: TokenData): string {
    return `jwt=${tokenData.refreshToken}; HttpOnly; Max-Age=${24 * 60 * 60 * 1000};`;
  }

  /**
   * @method createLoginTokens
   * @param user
   * @returns { cookie, accessToken }
   * @description  Creates login tokens and stores refresh token in db
   */
  public async createLoginTokens(user: User): Promise<{ cookie: string; accessToken: string }> {
    const tokenData = this.createToken(user);

    // store the refresh token in db
    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + this.refreshExpiry);

    await prisma.userToken.create({
      data: {
        userId: user.id,
        token: tokenData.refreshToken,
        expiry: expiryDate,
      },
    });

    const cookie = this.createCookie(tokenData);
    const accessToken = tokenData.token;
    return { cookie, accessToken };
  }

  /**
   * @method sendVerificationLink
   * @param user email
   * @returns { cookie, accessToken }
   * @description  Creates login tokens and stores refresh token in db
   */
  public async sendVerificationLink(user: string, email: string): Promise<void> {
    const emailKey = EMAIL_KEY;
    const dataStoredInEmailToken: DataStoredInEmailToken = { id: user };
    const token = sign(dataStoredInEmailToken, emailKey, { expiresIn: `${this.emailExpiry}m` });
    const expiryDate = new Date();
    expiryDate.setHours(expiryDate.getHours() + this.emailExpiry);
    await prisma.emailToken.create({
      data: {
        userId: user,
        token: token,
        email: email,
        expiry: expiryDate,
      },
    });
    // need to change to email to user email
    const message = {
      to: email,
      from: 'vivek.b@neoito.com',
      subject: 'Comunify Invitation',
      html: `<a href="http://localhost:${PORT}/auth/verifyEmail/${token}">Click to Verify</a>`, // change this to proper template
    };

    await sendgrid.send(message);
  }
}

export default AuthService;
