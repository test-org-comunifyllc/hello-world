import { hash } from 'bcrypt';
import { CreateUserDto } from '@modules/users/dto/users.dto';
import { HttpException } from '@exceptions/HttpException';
import { isEmpty } from '@utils/util';
import prisma from '@utils/prisma';
import { User } from '@modules/users/interface/users.interface';

class UserService {
  public async findAllUser(): Promise<User[]> {
    const allUser: User[] = await prisma.user.findMany();
    return allUser;
  }

  public async findUserById(userId: string): Promise<User> {
    if (isEmpty(userId)) throw new HttpException(400, "You're not userId");

    const findUser: User = await prisma.user.findUnique({
      where: {
        id: userId,
      },
    });
    if (!findUser) throw new HttpException(409, "You're not user");

    return findUser;
  }

  public async createUser(userData: CreateUserDto): Promise<User> {
    if (isEmpty(userData)) throw new HttpException(400, `You're not ${userData.userName}`);

    const findUser: User = await prisma.user.findUnique({ where: { email: userData.email } });
    if (findUser) throw new HttpException(409, `Your email ${userData.email} already exists`);

    const hashedPassword = await hash(userData.password, 10);
    const createUserData: User = await prisma.user.create({ data: { ...userData, password: hashedPassword } });

    return createUserData;
  }

  public async updateUser(userId: string, userData: CreateUserDto): Promise<User> {
    if (isEmpty(userData)) throw new HttpException(400, `You're not ${userData.email}`);

    const findUser: User = await prisma.user.findUnique({ where: { id: userId } });
    if (!findUser) throw new HttpException(409, "You're not user");

    const hashedPassword = await hash(userData.password, 10);
    await prisma.user.update({ data: { ...userData, password: hashedPassword }, where: { id: userId } });

    const updateUser: User = await prisma.user.findUnique({ where: { id: userId } });
    return updateUser;
  }

  public async deleteUser(userId: string): Promise<User> {
    if (isEmpty(userId)) throw new HttpException(400, "You're not userId");

    const findUser: User = await prisma.user.findUnique({ where: { id: userId } });
    if (!findUser) throw new HttpException(409, "You're not user");

    await prisma.user.delete({ where: { id: userId } });

    return findUser;
  }
}

export default UserService;
