import { Context } from 'koa';

import { CreateUserDto } from '@modules/users/dto/users.dto';
import { User } from '@modules/users/interface/users.interface';
import userService from '@modules/users/services/users.service';

class UsersController {
  public userService = new userService();

  public getUsers = async (ctx: Context) => {
    const findAllUsersData: User[] = await this.userService.findAllUser();
    ctx.response.body = { data: findAllUsersData, message: 'findAll' };
    ctx.response.status = 200;
  };

  public getUserById = async (ctx: Context) => {
    const userId = ctx.params.id;
    const findOneUserData: User = await this.userService.findUserById(userId);
    ctx.response.body = { data: findOneUserData, message: 'findOne' };
    ctx.response.status = 200;
  };

  public createUser = async (ctx: Context) => {
    const userData: CreateUserDto = ctx.request.body;
    const createUserData: User = await this.userService.createUser(userData);
    ctx.response.body = { data: createUserData, message: 'created' };
    ctx.response.status = 201;
  };

  public updateUser = async (ctx: Context) => {
    const userId = ctx.params.id;
    const userData: CreateUserDto = ctx.request.body;
    const updateUserData: User = await this.userService.updateUser(userId, userData);

    ctx.response.body = { data: updateUserData, message: 'updated' };
    ctx.response.status = 201;
  };

  public deleteUser = async (ctx: Context) => {
    const userId = ctx.params.id;
    const deleteUserData: User = await this.userService.deleteUser(userId);

    ctx.response.body = { data: deleteUserData, message: 'deleted' };
    ctx.response.status = 201;
  };
}

export default UsersController;
