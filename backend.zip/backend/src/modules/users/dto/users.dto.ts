import { IsString, IsEmail, IsOptional } from 'class-validator';

export class CreateUserDto {
  @IsEmail()
  public email: string;

  @IsString()
  public password: string;

  @IsString()
  public userName: string;

  @IsString()
  @IsOptional()
  public companyName: string;

  @IsString()
  public domain: string;
}
