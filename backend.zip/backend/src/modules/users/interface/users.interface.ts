export interface User {
  id: string;
  email: string;
  password: string;
  userName: string;
  companyName?: string;
  domain: string;
  isVerified: boolean;
}

export interface UserAuth {
  id: string;
  email: string;
  password: string;
}
