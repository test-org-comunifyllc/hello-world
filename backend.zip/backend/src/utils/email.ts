import sendgrid from '@sendgrid/mail';

import { SEND_GRID } from '@config';

const SENDGRID_API_KEY = SEND_GRID;

sendgrid.setApiKey(SENDGRID_API_KEY);

export default sendgrid;
