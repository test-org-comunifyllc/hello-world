import Koa from 'koa';
import { Struct, validate, Failure } from 'superstruct';
import { cleanEnv, port, str } from 'envalid';
import validator from 'validator';

/**
 * Function to validate environment variables.
 */
export const validateEnv = () => {
  cleanEnv(process.env, {
    NODE_ENV: str(),
    PORT: port(),
    DATABASE_URL: str(),
    LOG_DIR: str(),
    SECRET_KEY: str(),
    REFRESH_KEY: str(),
    EMAIL_KEY: str(),
    SEND_GRID: str(),
  });
};

/**
 * Function to assert/validate UUID.
 * @param ctx Koa context
 * @param uuid UUID value
 * @param message Appropriate message for failure
 */
export const assertUUID = (ctx: Koa.Context, uuid: string, message: string) => {
  ctx.assert(validator.isUUID(uuid), 404, message);
};

export class ValidationError extends Error {
  constructor(public errors: Failure[]) {
    super('Invalid request body');
  }
}

/**
 * Function to validate request body.
 * @param structObj SuperStruct object
 * @returns valid data with Types assigned
 */
export const validateData = <T>(structObj: Struct<T>) => {
  return function (ctx: Koa.Context, body: unknown = ctx.request.body) {
    const [error, res] = validate(body, structObj, { coerce: true });
    if (error) {
      ctx.throw(new ValidationError(error.failures()));
    }
    return res;
  };
};
