import compression from 'koa-compress';
import cors from '@koa/cors';
import Koa, { Context, DefaultState } from 'koa';
import koaBody from 'koa-body';
import helmet from 'koa-helmet';
import passport from 'koa-passport';
import requestLogger from 'koa-logger';

import { NODE_ENV, PORT, ORIGIN, CREDENTIALS } from '@config';
import { Routes } from '@interfaces/interface';
import errorMiddleware from '@middlewares/error.middleware';
import { logger, stream } from '@utils/logger';

class App {
  public app: Koa;
  public env: string;
  public port: string | number;

  constructor(routes: Routes[]) {
    this.app = new Koa<DefaultState, Context>();
    this.env = NODE_ENV || 'development';
    this.port = PORT || 3000;

    this.initializeMiddlewares();
    this.initializeErrorHandling();
    this.initializeRoutes(routes);
  }

  public listen() {
    this.app.listen(this.port, () => {
      logger.info(`  Running the ${this.env.charAt(0).toUpperCase() + this.env.slice(1)} server on Port: ${this.port}`);
    });
  }

  public getServer() {
    return this.app;
  }

  private initializeMiddlewares() {
    this.app.use(
      requestLogger((str: string) => {
        stream.write(str);
      }),
    );
    this.app.use(cors({ origin: ORIGIN, credentials: CREDENTIALS }));
    this.app.use(
      helmet({
        contentSecurityPolicy: NODE_ENV === 'development' ? false : true,
      }),
    );
    this.app.use(compression());
    this.app.use(koaBody());
    this.app.use(passport.initialize());
    require('./stratergies/jwt');
    require('./stratergies/google');
  }

  private initializeRoutes(routes: Routes[]) {
    routes.forEach(route => {
      this.app.use(route.router.routes()).use(route.router.allowedMethods());
    });
  }

  private initializeErrorHandling() {
    this.app.use(errorMiddleware);
  }
}

export default App;
